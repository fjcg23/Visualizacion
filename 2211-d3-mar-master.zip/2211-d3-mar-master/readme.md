# Bienvenido a la clase de Herramientas de Visualización

Aquí vamos a poner los proyectos que vayamos realizando

* Intro a D3
* Carga desde una API